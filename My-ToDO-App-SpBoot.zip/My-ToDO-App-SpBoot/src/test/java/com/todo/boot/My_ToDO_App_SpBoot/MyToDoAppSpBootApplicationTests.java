package com.todo.boot.My_ToDO_App_SpBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyToDoAppSpBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
