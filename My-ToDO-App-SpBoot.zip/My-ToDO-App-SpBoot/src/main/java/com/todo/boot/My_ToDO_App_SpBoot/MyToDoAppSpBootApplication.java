package com.todo.boot.My_ToDO_App_SpBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyToDoAppSpBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyToDoAppSpBootApplication.class, args);
	}

}
